const $=s=>document.querySelector(s);
const PRICE={cheap:0.05,strong:0.6}; // illustrative $ per 1M tokens
const EASY=["capital","translate","define","what is","summarize","spell","convert","list","rewrite"];
const HARD=["prove","derive","step by step","optimi","debug","analy","compare","why","design","algorithm","integral","code"];
function hash(s){let h=7;for(const c of s)h=(h*31+c.charCodeAt(0))>>>0;return h}
function rng(n){let x=n%2147483647||1;return()=>(x=x*16807%2147483647)/2147483647}
function score(p){p=p.toLowerCase();const w=p.trim().split(/\s+/).filter(Boolean).length;
 let s=0.78-Math.min(w,120)/120*0.32;EASY.forEach(k=>{if(p.includes(k))s+=0.1});HARD.forEach(k=>{if(p.includes(k))s-=0.14});
 if(/\d.*[+\-*/^=].*\d/.test(p))s-=0.1;if(/```|def |function |class /.test(p))s-=0.12;return Math.max(.03,Math.min(.97,s))}
function info(p,t){const w=p.trim().split(/\s+/).filter(Boolean).length,s=score(p),cheap=s>=t,tok=Math.round(w*1.4)+150,r=rng(hash(p));
 return{s,cheap,per1k:tok*(cheap?PRICE.cheap:PRICE.strong)/1e6*1000,base1k:tok*PRICE.strong/1e6*1000,lat:cheap?320+r()*200:900+r()*600,rl:8+r()*6}}
const usd=v=>"$"+v.toFixed(3);
function pareto(svg,t,color){const X=x=>50+x*500,Y=y=>270-(y-55)/35*240,q=x=>62+22*(1-Math.pow(1-x,2.6));let h="";
 [60,70,80,90].forEach(y=>h+=`<line x1="50" x2="550" y1="${Y(y)}" y2="${Y(y)}" stroke="#d5dbe6"/><text class="svgsub" x="8" y="${Y(y)+4}">${y}%</text>`);
 [0,25,50,75,100].forEach(x=>h+=`<text class="svgsub" x="${X(x/100)-10}" y="295">${x}%</text>`);
 h+=`<text class="svgsub" x="50" y="315">Cost compared with always using the strong model</text>`;
 h+=`<line x1="${X(0)}" y1="${Y(62)}" x2="${X(1)}" y2="${Y(84)}" stroke="#5b6478" stroke-dasharray="6 5" stroke-width="2"/>`;
 let pts="";for(let i=0;i<=20;i++){const x=i/20;pts+=`${X(x)},${Y(q(x))} `}
 h+=`<polyline points="${pts}" fill="none" stroke="#14213d" stroke-width="3.5"/>`;
 h+=`<text class="svgtxt" x="${X(.3)}" y="${Y(q(.3))-12}">Trained router</text><text class="svgsub" x="${X(.55)}" y="${Y(62+22*.55)+22}">Random routing</text>`;
 const x=0.1+(t-0.3)/0.6*0.8;
 h+=`<circle cx="${X(x)}" cy="${Y(q(x))}" r="11" fill="${color}" opacity=".25"/><circle cx="${X(x)}" cy="${Y(q(x))}" r="6" fill="${color}"/>`;
 svg.innerHTML=h}
function move(dot,path,reduced){const L=path.getTotalLength();if(reduced){const p=path.getPointAtLength(L);dot.setAttribute("cx",p.x);dot.setAttribute("cy",p.y);return}
 const t0=performance.now();(function f(n){const k=Math.min(1,(n-t0)/900),p=path.getPointAtLength(L*k);dot.setAttribute("cx",p.x);dot.setAttribute("cy",p.y);if(k<1)requestAnimationFrame(f)})(t0)}
function playground(){const ta=$("#prompt"),tr=$("#t"),reduced=matchMedia("(prefers-reduced-motion: reduce)").matches;let last="";
 function run(){const p=ta.value,t=+tr.value;$("#tv").textContent=t.toFixed(2);const i=info(p||"x",t),col=i.cheap?"var(--cheap)":"var(--strong)";
  $("#rc").className="rail cheap"+(p&&i.cheap?"":" off");$("#rs").className="rail strong"+(p&&!i.cheap?"":" off");
  document.querySelectorAll(".rail.off").forEach(e=>e.setAttribute("class","rail"));
  if(p){$("#tag").style.background=col;$("#route").textContent=i.cheap?"Cheap model":"Strong model";
   $("#why").textContent=`The router is ${Math.round(i.s*100)}% sure the cheap model can answer this. Your threshold is ${t.toFixed(2)}.`;
   $("#c1").textContent=usd(i.per1k);$("#c0").textContent=usd(i.base1k);$("#sv").textContent=Math.round((1-i.per1k/i.base1k)*100)+"%";
   $("#lat").textContent=Math.round(i.lat)+" ms";$("#rl").textContent=Math.round(i.rl)+" ms";
   if(p!==last){move($("#dot"),i.cheap?$("#rc"):$("#rs"),reduced);last=p}else move($("#dot"),i.cheap?$("#rc"):$("#rs"),true)}
  else{$("#route").textContent="Waiting for a prompt";$("#why").textContent="Type a prompt or pick an example to see where it goes.";$("#tag").style.background="var(--mute)"}
  pareto($("#pareto"),t,p?col:"#14213d")}
 ta.addEventListener("input",run);tr.addEventListener("input",run);
 document.querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>{ta.value=b.dataset.p;run()});run()}
function dashboard(){const r=rng(42),sc=[];for(let i=0;i<400;i++)sc.push(Math.min(.97,Math.max(.03,(r()+r()+r())/3*1.15-.02)));
 const T=.6,share=sc.filter(s=>s>=T).length/sc.length;$("#reqs").textContent="12,480";$("#share").textContent=Math.round(share*100)+"%";
 $("#save").textContent=Math.round(share*(1-PRICE.cheap/PRICE.strong)*100)+"%";$("#p95").textContent="14 ms";
 $("#split").innerHTML=`<div style="width:${share*100}%;background:var(--cheap)"></div><div style="flex:1;background:var(--strong)"></div>`;
 const bins=Array(10).fill(0);sc.forEach(s=>bins[Math.min(9,Math.floor(s*10))]++);const m=Math.max(...bins);
 $("#hist").innerHTML=bins.map((b,i)=>`<div class="${i>=6?"c":""}" style="height:${b/m*100}%" title="${i*10}-${i*10+10}%: ${b}"></div>`).join("");
 const P=["Translate good morning to Tamil","Summarize this paragraph in two lines","Derive the gradient of softmax cross-entropy","Debug this Python function that returns None","What is the capital of Australia","Compare B-trees and LSM trees for write-heavy loads","Convert 72 F to Celsius","Design an algorithm to schedule 50 exams without clashes"];
 $("#rows").innerHTML=P.map(p=>{const i=info(p,T);return`<tr><td>${p}</td><td>${Math.round(i.s*100)}%</td><td><span class="pill" style="background:${i.cheap?"var(--cheap)":"var(--strong)"}">${i.cheap?"Cheap":"Strong"}</span></td><td>${Math.round(i.lat)} ms</td><td>${usd(i.per1k)}</td></tr>`}).join("")}
document.addEventListener("DOMContentLoaded",()=>{$("#prompt")?playground():dashboard()});
